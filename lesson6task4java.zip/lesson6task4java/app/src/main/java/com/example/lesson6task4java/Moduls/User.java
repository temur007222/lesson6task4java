package com.example.lesson6task4java.Moduls;

public class User {
    String name;

    public User(String name){
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }

    public String getLastname() {
        return name;
    }
}
