package com.example.lesson6task4java.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.lesson6task4java.Adapters.RecyclerAdapter;
import com.example.lesson6task4java.Moduls.Member;
import com.example.lesson6task4java.Moduls.User;
import com.example.lesson6task4java.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    int LAUNCHER_DETAIL = 112;
    Context context;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        List<User> user = prepareMemberList();
        refreshAdapter((ArrayList<User>) user);
    }

    public void initView() {
        context = this;
        recyclerView =findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(context, 1));

    }

    public void refreshAdapter(ArrayList<User> users) {
        RecyclerAdapter adapter = new RecyclerAdapter(context, users);
        recyclerView.setAdapter(adapter);
        recyclerView.setNestedScrollingEnabled(false);
    }

    public List<User> prepareMemberList() {
        List<User> users = new ArrayList<>();
        users.add(new User( "Button "));
        return users;
    }
    public void onClick(View view){
        Button b_detail = findViewById(R.id.b_detail);
       b_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Member member = new Member(18, "Temur");
                openDetail(member);}
        });
    }
    void openDetail(Member member){

        Intent intent = new Intent(this, ProfileActivity.class);
        intent.putExtra("member", member);
        startActivityForResult(intent, LAUNCHER_DETAIL);
    }
}